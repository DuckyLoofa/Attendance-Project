document.addEventListener('DOMContentLoaded', function () {
    // Event listener for the login button
    document.getElementById('Login').addEventListener('click', function () {
        console.log('Button clicked'); // Log to check if the button is clicked

        // Get user input
        const studentId = document.getElementById('student-id').value;
        const password = document.getElementById('password').value;

        console.log('User input:', studentId, password); // Log user input

        // Fetch and verify data from the student text database
        fetch('Stu-Emails.txt')
            .then(response => response.text())
            .then(data => {
                console.log('Data from Stu-Emails.txt:', data); // Log data

                // Split data into lines
                const lines = data.split('\n');

                // Check for a match in student data
                let matchFound = false;

                for (let i = 0; i < lines.length; i++) {
                    const [lastName,firstName,email,storedId,storedPassword] = lines[i].split(',');

                    if (studentId === storedId && password === storedPassword) {
                        matchFound = true;
                        break;
                    }
                }

                console.log('Match found:', matchFound); // Log if a match is found for debugging

                // Redirect or show an alert based on the match result
                if (matchFound) {
                    // Redirect to the next page for students
                    window.location.href = 'CodeEntry.html';
                } else {
                    // If not found, show an alert
                    alert('Invalid Student ID or Password. Please try again.');
                }
            })
				.catch(error => {
					console.error('Error fetching or parsing data:', error);
					alert(`An error occurred while processing your request. Details: ${error.message}`);
				});

    });
});
