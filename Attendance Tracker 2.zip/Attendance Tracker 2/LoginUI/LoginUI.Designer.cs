﻿namespace LoginUI
{
    partial class StudentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bg = new System.Windows.Forms.TextBox();
            this.StudentID = new System.Windows.Forms.MaskedTextBox();
            this.StudentPass = new System.Windows.Forms.MaskedTextBox();
            this.enter = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bg
            // 
            this.bg.AcceptsTab = true;
            this.bg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bg.Enabled = false;
            this.bg.Location = new System.Drawing.Point(93, 112);
            this.bg.Multiline = true;
            this.bg.Name = "bg";
            this.bg.ReadOnly = true;
            this.bg.Size = new System.Drawing.Size(326, 196);
            this.bg.TabIndex = 2;
            // 
            // StudentID
            // 
            this.StudentID.BackColor = System.Drawing.SystemColors.Window;
            this.StudentID.Location = new System.Drawing.Point(147, 158);
            this.StudentID.Name = "StudentID";
            this.StudentID.Size = new System.Drawing.Size(213, 20);
            this.StudentID.TabIndex = 3;
            this.StudentID.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.StudentID_MaskInputRejected);
            // 
            // StudentPass
            // 
            this.StudentPass.BackColor = System.Drawing.Color.White;
            this.StudentPass.Location = new System.Drawing.Point(147, 184);
            this.StudentPass.Name = "StudentPass";
            this.StudentPass.Size = new System.Drawing.Size(213, 20);
            this.StudentPass.TabIndex = 4;
            this.StudentPass.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.StudentPass_MaskInputRejected);
            // 
            // enter
            // 
            this.enter.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enter.Location = new System.Drawing.Point(147, 225);
            this.enter.Name = "enter";
            this.enter.Size = new System.Drawing.Size(213, 44);
            this.enter.TabIndex = 5;
            this.enter.Text = "LOGIN";
            this.enter.UseVisualStyleBackColor = true;
            this.enter.Click += new System.EventHandler(this.enter_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(93, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(326, 57);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // StudentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LimeGreen;
            this.ClientSize = new System.Drawing.Size(521, 349);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.enter);
            this.Controls.Add(this.StudentPass);
            this.Controls.Add(this.StudentID);
            this.Controls.Add(this.bg);
            this.Name = "StudentInfo";
            this.Text = "Student Info";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox bg;
        private System.Windows.Forms.MaskedTextBox StudentID;
        private System.Windows.Forms.MaskedTextBox StudentPass;
        private System.Windows.Forms.Button enter;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

