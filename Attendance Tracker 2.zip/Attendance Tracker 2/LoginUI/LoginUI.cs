﻿using System;
using System.Windows.Forms;

namespace LoginUI
{
    public partial class StudentInfo : Form
    {
        public StudentInfo()
        {
            InitializeComponent();
        }

        private void StudentID_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            // Your code for StudentID_MaskInputRejected
        }

        private void StudentPass_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            // Your code for StudentPass_MaskInputRejected
        }

        private void enter_Click(object sender, EventArgs e)
        {
            // Create an instance of the CodeUI form and show it
            CodeUI form2 = new CodeUI();
            form2.ShowDialog();

           // Close the old form
           // this.Close();
        }
    }

    // Define the CodeUI class outside the event handler
    public class CodeUI : Form
    {
        public CodeUI()
        {
        }
    }
}
