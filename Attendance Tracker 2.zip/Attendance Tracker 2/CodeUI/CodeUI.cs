﻿using System;
using System.Windows.Forms;

namespace CodeUI
{
    public partial class CodeUI : Form
    {
        public CodeUI()
        {
            InitializeComponent();
            this.Load += CodeUILoadHandler; // Rename the event handler
        }

        private void CodeUILoadHandler(object sender, EventArgs e)
        {
            // Your custom initialization code for CodeUI
        }

        private void enter_Click(object sender, EventArgs e)
        {
            // Handle the button click event
        }
    }
}
