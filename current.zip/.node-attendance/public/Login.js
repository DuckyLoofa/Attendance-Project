document.getElementById('Login').addEventListener('click', async function () {
  const id = document.getElementById('student-id').value;
  const password = document.getElementById('password').value;

  try {
    const response = await fetch('./students.json');
    const students = await response.json();

    const matchFound = students.some(student => {
      return id === students.id && students.password === password;
    });

    if (matchFound) {
      window.location.href = 'CodeEntry.html';
    } else {
      alert('Invalid Student ID or Password. Please try again.');
    }
  } catch (error) {
    console.error('Error fetching or parsing data:', error);
    alert(`An error occurred while processing your request. Details: ${error.message}`);
  }
});
