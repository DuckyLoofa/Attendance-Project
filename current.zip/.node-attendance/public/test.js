document.addEventListener('DOMContentLoaded', function () {
    const hardcodedStudentId = '11003';
    const hardcodedPassword = 'ACho1432';

    document.getElementById('Login').addEventListener('click', function (event) {
        event.preventDefault(); // Prevent the default form submission

        console.log('Button clicked'); // Log to check if the button is clicked

        const studentId = document.getElementById('student-id').value;
        const password = document.getElementById('password').value;

        console.log('User input:', studentId, password); // Log user input

        // Check if user input matches the hardcoded credentials
        if (studentId === hardcodedStudentId && password === hardcodedPassword) {
            // Redirect to the next page for students
            window.location.href = 'CodeEntry.html';
        } else {
            // If not found, show an alert
            alert('Invalid Student ID or Password. Please try again.');
        }
    });
});
