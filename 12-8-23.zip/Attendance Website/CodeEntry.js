document.addEventListener('DOMContentLoaded', function () {
    // Function to generate a random code
    function generateRandomCode() {
        const characters = '0123456789';
        const codeLength = 6; 

        let randomCode = '';
        for (let i = 0; i < codeLength; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            randomCode += characters.charAt(randomIndex);
        }
        console.log(randomCode);
        return randomCode;
    }

    // Display the random code in a pop-up when the page loads
    const randomCode = generateRandomCode();
    alert(`Your code for today is: ${randomCode}`);

    // Event listener for the "Enter" button
    document.querySelector('.code-form button').addEventListener('click', function () {
        event.preventDefault();

        // Get user input
        const enteredCode = document.querySelector('.code-form input').value;

        // Check if the entered code matches the generated random code
        if (enteredCode === randomCode) {
            // Code is correct, you can proceed with logging attendance
            alert('Attendance marked successfully!');
            window.location.href = 'IntermediateScreen.html'; 
        } else {
            // Code is incorrect, show an alert
            alert('Incorrect code. Please try again.');
        }
    });
});
