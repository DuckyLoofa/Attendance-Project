document.addEventListener('DOMContentLoaded', function () {
  // Retrieve sign-in data from sessionStorage
  const signInData = JSON.parse(sessionStorage.getItem('signInData')) || [];

  // Display the sign-in data in the report container
  const reportContainer = document.getElementById('report-container');

  signInData.forEach(entry => {
    const user = students.find(student => student.id === entry.userId);
    const row = document.createElement('div');
    row.textContent = `${user.firstName} ${user.lastName} - ${entry.timestamp}`;
    reportContainer.appendChild(row);
  });
});
