document.addEventListener('DOMContentLoaded', function () {
	
document.getElementById('Login').addEventListener('click', function () {
  console.log('Login button clicked');

  const id = document.getElementById("student-id").value;
  const password = document.getElementById("password").value;

  console.log('ID:', id);
  console.log('Password:', password);

  const matchFound = students.some(student => {
    return id === student.id && password === student.password;
  });

  if (matchFound) {
    window.location.href = 'IntermediateScreen.html';
  } else {
    alert('Invalid Student ID or Password. Please try again.');
  }
});

});