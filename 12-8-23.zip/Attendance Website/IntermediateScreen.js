document.addEventListener('DOMContentLoaded', function () {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));

  if (currentUser) {
    document.getElementById('welcome-message').textContent = `Welcome, ${currentUser.firstName} ${currentUser.lastName}!`;
  }

  document.getElementById('reportButton').addEventListener('click', function () {
    window.location.href = 'ReportPage.html';
  });

  document.getElementById('signInButton').addEventListener('click', function () {
    window.location.href = 'CodeEntry.html';
  });
  
  document.getElementById('logOutButton').addEventListener('click', function () {
    window.location.href = 'LoginScreen.html';
  });
});
